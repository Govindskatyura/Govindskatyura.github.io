$(document).ready(function()
{
	$(".st").click(function()
	{
		$(".secscroll").css("margin-left","-100px");
	});
})